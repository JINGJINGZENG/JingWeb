import tensorflow as tf
from tensorflow import keras

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

train = pd.read_csv('fashion-mnist_train.csv') # 读取训练集
test = pd.read_csv('fashion-mnist_test_data.csv') # 读取测试集
class_names = ['T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat',
               'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot'] #类别名

##数据预处理
#整理数据集
train_labels=train['label'].copy()
del train['label']
del test['iD']

# dataframe -> ndarray
train1 = train.values
train_labels = train_labels.values
test1 = test.values

#数据归一化
train2 = train1 / 255.0
test2 = test1 / 255.0

#从训练集中分出验证集
train3 = train2[0:42000].copy() #训练集
vali = train2[42000:60000].copy() #验证集
train_label = train_labels[0:42000].copy()#训练集
vali_label = train_labels[42000:60000].copy()#验证集

#将数据转换为三维数组形式
#训练集
train_3D = np.zeros([42000,28,28])
for i in range(0,42000):
    j=0
    k=0
    while(k<28 and j<28):
        train_3D[i,j,k]=train3[i,j*28+k]
        k=k+1
        if k==28:
            j=j+1
            k=0

#验证集
vali_3D = np.zeros([18000,28,28])
for i in range(0,18000):
    j=0
    k=0
    while(k<28 and j<28):
        vali_3D[i,j,k]=vali[i,j*28+k]
        k=k+1
        if k==28:
            j=j+1
            k=0
#测试集
test_3D = np.zeros([10000,28,28])
for i in range(0,10000):
    j=0
    k=0
    while(k<28 and j<28):
        test_3D[i,j,k]=test2[i,j*28+k]
        k=k+1
        if k==28:
            j=j+1
            k=0

##画图
plt.figure()
plt.imshow(train1_3D[1])
plt.colorbar()
plt.grid(False)
plt.show()

plt.figure(figsize=(10,10))
for i in range(25):
    plt.subplot(5,5,i+1)
    plt.xticks([])
    plt.yticks([])
    plt.grid(False)
    plt.imshow(train1_3D[i], cmap=plt.cm.binary)
    plt.xlabel(class_names[train_label1[i]])
plt.show()

##顺序全连接模型
#建立模型
model = keras.Sequential([
    keras.layers.Flatten(),
    keras.layers.Dense(128, activation='relu'),
    keras.layers.Dense(10)
])
#配置训练相关参数
model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
              loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
              metrics=['accuracy'])
#模型训练拟合并验证
fit = model.fit(train3, train_label , batch_size=32, epochs=10, validation_data=(vali,vali_label))

#画出准确率图
fit.history.keys()
plt.figure()
plt.plot(fit.epoch,fit.history.get('accuracy'),label="accuracy")
plt.plot(fit.epoch,fit.history.get('val_accuracy'),label="val_accuracy")
plt.legend()
#画出损失率图
plt.figure()
plt.plot(fit.epoch,fit.history.get('loss'),label="loss")
plt.plot(fit.epoch,fit.history.get('val_loss'),label="val_loss")
plt.legend()

#进行预测
probability_model = tf.keras.Sequential([model,tf.keras.layers.Softmax()])
predictions = probability_model.predict(train4)

def plot_image(i, predictions_array, true_label, img):
  predictions_array, true_label, img = predictions_array, true_label[i], img[i]
  plt.grid(False)
  plt.xticks([])
  plt.yticks([])

  plt.imshow(img, cmap=plt.cm.binary)

  predicted_label = np.argmax(predictions_array)
  if predicted_label == true_label:
    color = 'blue'
  else:
    color = 'red'

  plt.xlabel("{} {:2.0f}% ({})".format(class_names[predicted_label],
                                100*np.max(predictions_array),
                                class_names[true_label]),
                                color=color)

def plot_value_array(i, predictions_array, true_label):
  predictions_array, true_label = predictions_array, true_label[i]
  plt.grid(False)
  plt.xticks(range(10))
  plt.yticks([])
  thisplot = plt.bar(range(10), predictions_array, color="#777777")
  plt.ylim([0, 1])
  predicted_label = np.argmax(predictions_array)

  thisplot[predicted_label].set_color('red')
  thisplot[true_label].set_color('blue')

i = 0
plt.figure(figsize=(6, 3))
plt.subplot(1, 2, 1)
plot_image(i, predictions[i], train4, train_label2)
plt.subplot(1, 2, 2)
plot_value_array(i, predictions[i], train_label2)
plt.show()

i = 12
plt.figure(figsize=(6,3))
plt.subplot(1,2,1)
plot_image(i, predictions[i], train_label2, train2_3D)
plt.subplot(1,2,2)
plot_value_array(i, predictions[i],  train_label2)
plt.show()

# Plot the first X test images, their predicted labels, and the true labels.
# Color correct predictions in blue and incorrect predictions in red.
num_rows = 5
num_cols = 3
num_images = num_rows*num_cols
plt.figure(figsize=(2*2*num_cols, 2*num_rows))
for i in range(num_images):
  plt.subplot(num_rows, 2*num_cols, 2*i+1)
  plot_image(i, predictions[i], train_label2, train2_3D)
  plt.subplot(num_rows, 2*num_cols, 2*i+2)
  plot_value_array(i, predictions[i], train_label2)
plt.tight_layout()
plt.show()