import tensorflow as tf
from tensorflow import keras

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

train = pd.read_csv('fashion-mnist_train.csv') # 读取训练集
test = pd.read_csv('fashion-mnist_test_data.csv') # 读取测试集
class_names = ['T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat',
               'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot'] #类别名

##数据预处理
#整理数据集
train_labels=train['label'].copy()
del train['label']
del test['iD']

# dataframe -> ndarray
train1 = train.values
train_labels = train_labels.values
test1 = test.values

#数据归一化
train2 = train1 / 255.0
test2 = test1 / 255.0

#从训练集中分出验证集
train3 = train2[0:45000].copy() #训练集
vali = train2[45000:60000].copy() #验证集
train_label = train_labels[0:45000].copy()#训练集
vali_label = train_labels[45000:60000].copy()#验证集

#将数据转换为三维数组形式
#训练集
train_3D = np.zeros([45000,28,28])
for i in range(0,45000):
    j=0
    k=0
    while(k<28 and j<28):
        train_3D[i,j,k]=train3[i,j*28+k]
        k=k+1
        if k==28:
            j=j+1
            k=0
#验证集
vali_3D = np.zeros([15000,28,28])
for i in range(0,15000):
    j=0
    k=0
    while(k<28 and j<28):
        vali_3D[i,j,k]=vali[i,j*28+k]
        k=k+1
        if k==28:
            j=j+1
            k=0

#将三维数组转换为四维数组形式
vali_4D = vali_3D.reshape((15000,28,28,1))
train_4D = train_3D.reshape((45000,28,28,1))

##画图
plt.figure()
plt.imshow(train_3D[1])
plt.colorbar()
plt.grid(False)
plt.show()

plt.figure(figsize=(10,10))
for i in range(25):
    plt.subplot(5,5,i+1)
    plt.xticks([])
    plt.yticks([])
    plt.grid(False)
    plt.imshow(train_3D[i], cmap=plt.cm.binary)
    plt.xlabel(class_names[train_label[i]])
plt.show()


##顺序卷积神经网络模型
#建立模型
model = keras.Sequential([
    keras.layers.Conv2D(32,kernel_size=3,strides=1,padding="same", data_format="channels_last", activation=tf.nn.relu),
    keras.layers.MaxPool2D(pool_size=2,strides=2,padding = 'same'),
    keras.layers.Conv2D(64,kernel_size=3,strides=1,padding="same", data_format="channels_last", activation=tf.nn.relu),
    keras.layers.MaxPool2D(pool_size=2,strides=2,padding = 'same'),
    keras.layers.Conv2D(128,kernel_size=3,strides=1,padding="same", data_format="channels_last", activation=tf.nn.relu),
    keras.layers.MaxPool2D(pool_size=2,strides=2,padding = 'same'),
    keras.layers.Flatten(),
    keras.layers.Dense(128, activation='relu'),
    keras.layers.Dropout(0.2),
    keras.layers.Dense(64, activation='relu'),
    keras.layers.Dropout(0.2),
    keras.layers.Dense(32, activation='relu'),
    keras.layers.Dropout(0.2),
    keras.layers.Dense(10)
])

#配置训练相关参数
model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
              loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
              metrics=['accuracy'])

#模型训练拟合并验证
fit = model.fit(train_4D, train_label, batch_size=128 ,epochs=10,validation_data=(vali_4D,vali_label))

#画出损失率图
plt.figure()
plt.plot(fit.epoch,fit.history.get('loss'),label="loss")
plt.plot(fit.epoch,fit.history.get('val_loss'),label="val_loss")
plt.legend()
#画出准确率图
fit.history.keys()
plt.figure()
plt.plot(fit.epoch,fit.history.get('accuracy'),label="accuracy")
plt.plot(fit.epoch,fit.history.get('val_accuracy'),label="val_accuracy")
plt.legend()

plt.figure()
history = pd.DataFrame(fit.history)
history.plot()