import tensorflow as tf
from tensorflow import keras

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

train = pd.read_csv('fashion-mnist_train.csv') # ��ȡѵ����
test = pd.read_csv('fashion-mnist_test_data.csv') # ��ȡ���Լ�
class_names = ['T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat',
               'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot'] #�����

##����Ԥ����
#�������ݼ�
train_labels=train['label'].copy()
del train['label']
del test['iD']

# dataframe -> ndarray
train1 = train.values
train_labels = train_labels.values
test1 = test.values

#���ݹ�һ��
train2 = train1 / 255.0
test2 = test1 / 255.0

#��ѵ�����зֳ���֤��
train3 = train2[0:42000].copy() #ѵ����
vali = train2[42000:60000].copy() #��֤��
train_label = train_labels[0:42000].copy()#ѵ����
vali_label = train_labels[42000:60000].copy()#��֤��

#������ת��Ϊ��ά������ʽ
#ѵ����
train_3D = np.zeros([42000,28,28])
for i in range(0,42000):
    j=0
    k=0
    while(k<28 and j<28):
        train_3D[i,j,k]=train3[i,j*28+k]
        k=k+1
        if k==28:
            j=j+1
            k=0

#��֤��
vali_3D = np.zeros([18000,28,28])
for i in range(0,18000):
    j=0
    k=0
    while(k<28 and j<28):
        vali_3D[i,j,k]=vali[i,j*28+k]
        k=k+1
        if k==28:
            j=j+1
            k=0
            
#���Լ�
test_3D = np.zeros([10000,28,28])
for i in range(0,10000):
    j=0
    k=0
    while(k<28 and j<28):
        test_3D[i,j,k]=test2[i,j*28+k]
        k=k+1
        if k==28:
            j=j+1
            k=0

#����ά����ת��Ϊ��ά������ʽ
vali_4D = vali_3D.reshape((15000,28,28,1))
train_4D = train_3D.reshape((45000,28,28,1))

##��ͼ
plt.figure()
plt.imshow(train_3D[1])
plt.colorbar()
plt.grid(False)
plt.show()

plt.figure(figsize=(10,10))
for i in range(25):
    plt.subplot(5,5,i+1)
    plt.xticks([])
    plt.yticks([])
    plt.grid(False)
    plt.imshow(train_3D[i], cmap=plt.cm.binary)
    plt.xlabel(class_names[train_label[i]])
plt.show()

##˳��ȫ����ģ��
#����ģ��
model1 = keras.Sequential([
    keras.layers.Flatten(),
    keras.layers.Dense(128, activation='relu'),
    keras.layers.Dense(10)
])

##˳�����������ģ��
model_CNN = keras.Sequential([
    keras.layers.Conv2D(32,kernel_size=3,strides=1,padding="same", data_format="channels_last", activation=tf.nn.relu),
    keras.layers.MaxPool2D(pool_size=2,strides=2,padding = 'same'),
    keras.layers.Conv2D(64,kernel_size=3,strides=1,padding="same", data_format="channels_last", activation=tf.nn.relu),
    keras.layers.MaxPool2D(pool_size=2,strides=2,padding = 'same'),
    keras.layers.Conv2D(128,kernel_size=3,strides=1,padding="same", data_format="channels_last", activation=tf.nn.relu),
    keras.layers.MaxPool2D(pool_size=2,strides=2,padding = 'same'),
    keras.layers.Flatten(),
    keras.layers.Dense(128, activation='relu'),
    keras.layers.Dropout(0.2),
    keras.layers.Dense(64, activation='relu'),
    keras.layers.Dropout(0.2),
    keras.layers.Dense(32, activation='relu'),
    keras.layers.Dropout(0.2),
    keras.layers.Dense(10)
])


#����ѵ����ز���
model1.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
              loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
              metrics=['accuracy'])

model_CNN.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
              loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
              metrics=['accuracy'])              
              
#ģ��ѵ����ϲ���֤
fit1 = model1.fit(train3, train_label , batch_size=32, epochs=10, validation_data=(vali,vali_label))

fit_CNN = model_CNN.fit(train_4D, train_label, batch_size=128 ,epochs=10,validation_data=(vali_4D,vali_label))

#����׼ȷ��ͼ
plt.figure()
plt.plot(fit1.epoch,fit1.history.get('accuracy'),label="accuracy")
plt.plot(fit1.epoch,fit1.history.get('val_accuracy'),label="val_accuracy")
plt.legend() 
#������ʧ��ͼ
plt.figure()
plt.plot(fit1.epoch,fit1.history.get('loss'),label="loss")
plt.plot(fit1.epoch,fit1.history.get('val_loss'),label="val_loss")
plt.legend()
#��ͼ
plt.figure()
history1 = pd.DataFrame(fit1.history)
history1.plot()

#������ʧ��ͼ
plt.figure()
plt.plot(fit_CNN.epoch,fit_CNN.history.get('loss'),label="loss")
plt.plot(fit_CNN.epoch,fit_CNN.history.get('val_loss'),label="val_loss")
plt.legend()
#����׼ȷ��ͼ
fit.history.keys()
plt.figure()
plt.plot(fit_CNN.epoch,fit_CNN.history.get('accuracy'),label="accuracy")
plt.plot(fit_CNN.epoch,fit_CNN.history.get('val_accuracy'),label="val_accuracy")
plt.legend()
#��ͼ
plt.figure()
history_CNN = pd.DataFrame(fit_CNN.history)
history_CNN.plot()

#����Ԥ��
probability_model2 = tf.keras.Sequential([model1,tf.keras.layers.Softmax()])
predictions2 = probability_model2.predict(vali)#��ģ��1Ԥ��
probability_model3 = tf.keras.Sequential([model_CNN,tf.keras.layers.Softmax()])
predictions3 = probability_model3.predict(vali_4D)#��ģ��2Ԥ��

def plot_image(i, predictions_array, true_label, img):
  predictions_array, true_label, img = predictions_array, true_label[i], img[i]
  plt.grid(False)
  plt.xticks([])
  plt.yticks([])

  plt.imshow(img, cmap=plt.cm.binary)

  predicted_label = np.argmax(predictions_array)
  if predicted_label == true_label:
    color = 'blue'
  else:
    color = 'red'

  plt.xlabel("{} {:2.0f}% ({})".format(class_names[predicted_label],
                                100*np.max(predictions_array),
                                class_names[true_label]),
                                color=color)

def plot_value_array(i, predictions_array, true_label):
  predictions_array, true_label = predictions_array, true_label[i]
  plt.grid(False)
  plt.xticks(range(10))
  plt.yticks([])
  thisplot = plt.bar(range(10), predictions_array, color="#777777")
  plt.ylim([0, 1])
  predicted_label = np.argmax(predictions_array)

  thisplot[predicted_label].set_color('red')
  thisplot[true_label].set_color('blue')

i = 0 #ȫ����Ԥ����
plt.figure(figsize=(6, 3))
plt.subplot(1, 2, 1)
plot_image(i, predictions1[i], vali, vali_label)
plt.subplot(1, 2, 2)
plot_value_array(i, predictions1[i], vali_label)
plt.show()
i = 0#����������Ԥ����
plt.figure(figsize=(6, 3))
plt.subplot(1, 2, 1)
plot_image(i, predictions_CNN[i], vali, vali_label)
plt.subplot(1, 2, 2)
plot_value_array(i, predictions_CNN[i], vali_label)
plt.show()

i = 12#ȫ����Ԥ����
plt.figure(figsize=(6,3))
plt.subplot(1,2,1)
plot_image(i, predictions1[i], vali_label, vali_3D)
plt.subplot(1,2,2)
plot_value_array(i, predictions1[i],  vali_label)
plt.show()

i = 12#����������Ԥ����
plt.figure(figsize=(6,3))
plt.subplot(1,2,1)
plot_image(i, predictions_CNN[i], vali_label, vali_3D)
plt.subplot(1,2,2)
plot_value_array(i, predictions_CNN[i],  vali_label)
plt.show()
# Plot the first X test images, their predicted labels, and the true labels.
# Color correct predictions in blue and incorrect predictions in red.
#ȫ����Ԥ����
num_rows = 5
num_cols = 3
num_images = num_rows*num_cols
plt.figure(figsize=(2*2*num_cols, 2*num_rows))
for i in range(num_images):
  plt.subplot(num_rows, 2*num_cols, 2*i+1)
  plot_image(i, predictions1[i], vali_label, vali_3D)
  plt.subplot(num_rows, 2*num_cols, 2*i+2)
  plot_value_array(i, predictions1[i], vali_label)
plt.tight_layout()
plt.show()
#����������Ԥ����
num_rows = 5
num_cols = 3
num_images = num_rows*num_cols
plt.figure(figsize=(2*2*num_cols, 2*num_rows))
for i in range(num_images):
  plt.subplot(num_rows, 2*num_cols, 2*i+1)
  plot_image(i, predictions_CNN[i], vali_label, vali_3D)
  plt.subplot(num_rows, 2*num_cols, 2*i+2)
  plot_value_array(i, predictions_CNN[i], vali_label)
plt.tight_layout()
plt.show()

#�þ���������ģ��Ԥ����Լ�
probability_model_CNN = tf.keras.Sequential([model_CNN,tf.keras.layers.Softmax()])
predictions_CNN = probability_model_CNN.predict(test_4D)

#����Ԥ����
result = pd.DataFrame(columns=['id','class'])
for i in range(10000):
    a = str(i)+'.jpg'
    b =  np.argmax(predictions_CNN[i])
    result.loc[i+1]={'id':a,'class':b}
    
#����Ԥ������result.csv
result.to_csv('result.csv', sep=',', header=False, index=False)