function x=zhuiganfa(A,d)
%首先说明：追赶法适用于三对角矩阵的线性方程组求解的方法，并不适用于其他类型矩阵。
%定义三对角矩阵A的各组成单元，方程为Ax=d.
%b为A的对角线元素(1~n),a为-1对角线元素(2~n),c为+1对角线元素(1~n-1)
a=[0 diag(A,-1)'];
b=diag(A)';
c=diag(A,1)';
n=length(b);
u0=0;y0=0;a(1)=0;
%“追”的过程
L(1)=b(1)-a(1)*u0;
y(1)=(d(1)-y0*a(1))/L(1);
u(1)=c(1)/L(1);
for i=2:(n-1)
    L(i)=b(i)-a(i)*u(i-1);
    y(i)=(d(i)-y(i-1)*a(i))/L(i);
    u(i)=c(i)/L(i);
end
L(n)=b(n)-a(n)*u(n-1);
y(n)=(d(n)-y(n-1)*a(n))/L(n);
%“赶”的过程
x(n)=y(n);
for i=(n-1):-1:1
    x(i)=y(i)-u(i)*x(i+1);
end