function[x,R,index]=DoolittleR(A,b)
%A为要分解的矩阵；
%R下三角阵为L的下三角阵（不包括对角线）；
%R上三角阵为U的上三角阵；
%b为方程组的右端项；
%x为方程组Ax=b的解；
%index以为指标变量，index=0，表示计算失败，index=1，表示计算成功
[m,n]=size(A);
if m~=n
    disp('Argument matrix A must be square!');
    index=0;
    return;
end
%开始计算，赋初值
index=1;
R(1,1:n)=A(1,1:n);
R(2:n,1)=A(2:n,1)/R(1,1);
for k=2:n
    for i=k:n
        R(k,i)=A(k,i)-R(k,1:(k-1))*R(1:(k-1),i);
    end
    if R(k,k)==0
        disp('The Linear System is singular!');
        index=0;
        return;
    end
    for j=(k+1):n
        R(j,k)=(A(j,k)-R(j,1:(k-1))*R(1:(k-1),k))/R(k,k);
    end
end
y(1)=b(1);
for k=1:n
    y(k)=b(k)-R(k,1:k-1)*y(1:k-1)';
end
x(n)=y(n)/R(n,n);
for k=n:-1:1
    x(k)=(y(k)-R(k,k+1:n)*x(k+1:n)')/R(k,k);
end