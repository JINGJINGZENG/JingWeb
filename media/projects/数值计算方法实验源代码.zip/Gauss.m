function[x,index]=Gauss(A,b)
%求线性方程组的高斯消元法
%A为方程组的系数矩阵；
%b为方程组的右端项；
%x为方程组的解；
%index为指标变量，index=0表示计算失败，index=1表示计算成功
[m,n]=size(A);
if m~=n
    disp('Argument matrix A must be square!');
    index=0;
    return;
elseif m~=length(b)
    disp('The dimentions of A and b do notagree!');
    index=0;
    return;
end
%开始计算，先赋初值
Ab=[A b];index=1;
%消元过程
for k=1:n-1
    if Ab(k,k)==0
        disp('index=0')
        index=0;
        return
    end
    Ab(k,:)=1/Ab(k,k)*Ab(k,:);
    for i=k+1:n
        Ab(i,:)=Ab(i,:)-Ab(i,k)*Ab(k,:);
    end
end
if Ab(n,n)==0
    disp('index=0')
    index=0;
    return
end
Ab(n,:)=1/Ab(n,n)*Ab(n,:);
%回代过程
x(n)=Ab(n,n+1)/Ab(n,n);
for j=n-1:-1:1
    x(j)=(Ab(j,n+1)-Ab(j,j+1:n)*x(j+1:n)')/Ab(j,j);
end