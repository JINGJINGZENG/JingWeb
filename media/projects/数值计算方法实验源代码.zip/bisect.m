function[x_star,index,it]=bisect(fun,a,b)
%求解非线性计算方程的二分法，其中，fun(x)为需要求根的函数;
%a,b为初始区间的端点;
%ep为精度，当(b-a)/2<ep时，算法能终止计算，
%缺省值为1e-5;
%当x_star迭代成功时，输出方程的根
%当x_start迭代失败时，输出两端点的值；
%index为指标变量，当index=1时，表明迭代成功，
%当index=0时，表明初始区间不是有根区间；
%it为迭代次数
if nargin<4
    ep=1e-5;
end
fa=feval(fun,a);fb=feval(fun,b);
if fa*fb>0
    x_star=[fa,fb];index=0;it=0;
    return;
end
k=1;
while abs(b-a)/2>=ep
    x=(a+b)/2;fx=feval(fun,x);
    if fx*fa<0
        b=x;fb=fx;
    else
        a=x;fa=fx;
    end
    k=k+1;
end
x_star=(a+b)/2;index=1;it=k;
