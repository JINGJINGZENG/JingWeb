# 学号：631810040303
# 姓名：曾晶晶
# 编写时间：2021/11/16
import math

source = {}
# 0.25,0.25,0.20,0.15,0.10,0.05
# a1,a2,a3,a4,a5,a6
pro_sum = []  # 概率累加和
k = {}  # 对应码长
length_k = 0  # 平均码长
H = 0  # 信源熵


def init():
    source_symbol = input('请输入信源符号（中间以逗号隔开）：')
    source_probability = eval(input('请输入信源符号对应的概率（中间以逗号隔开,不要有空格）：'))
    ss_list = source_symbol.split(",")
    assert len(ss_list) == len(source_probability), '信源模型错误，符号个数和概率对不上'
    source = dict(zip(ss_list, source_probability))
    print('信源模型为:{}'.format(source))
    return source


def probability_summation():
    m = 0.0
    pro_sum.append(m)
    for i in list(source.values()):
        pro_sum.append(round(m + float(i), 4))
        m += float(i)
        if len(pro_sum) == len(source):
            break
    print("累加概率依次为：{}".format(pro_sum))


def code_length(k1):
    for item in source:
        k1[item] = math.ceil(math.log(float(source.get(item)), 2) * (-1))
    print('码长：{}'.format(k))
    return k1

def average_length(lk, s, kd):
    for item in s:
        lk += float(kd[item]) * float(s[item])
    print("平均码长为：{:.3}(bit/sign)".format(lk))
    return lk


def Hx(h, s):
    for item in s:
        h += float(s[item]) * math.log(float(s[item]), 2) * (-1)
    print('信源熵：{:.5}(bit/sign)'.format(h))
    return h


# 将十进制小数转为二进制小数
def float_to_bin(px, lk):
    b = []
    while True:
        px *= 2
        b.append(1 if px >= 1 else 0)
        px -= int(px)
        if px == 0 and len(b) != lk:
            b.append('0' * (lk - len(b)))
            break
        elif len(b) == lk:
            break
    return b


def codeword():
    code = source.copy()  # 对应码字
    i = 0
    for item in source:
        e = ''
        j = 0
        bin = float_to_bin(float(pro_sum[i]), k[item])
        while len(e) != k[item]:
            e += str(bin[j])
            j += 1
        code[item] = e
        i += 1
    print('码字：{}'.format(code))


def efficiency(hx, lk):
    print('编码效率：{:.2%}'.format(hx / round(lk, 3)))

if __name__ == '__main__':
    # 利用字典的形式存储信源符号及其概率
    print('以下为香农编码过程')
    source = init()  # 输入信源概率模型
    source = sorted(source.items(), key=lambda kv: kv[1], reverse=True)  # 将概率值从大到小排序
    source = dict(source)
    print(source)
    print("将概率值从大到小排序:{}".format(source))
    probability_summation()  # 求概率累加和
    k = source.copy()
    k = code_length(k)  # 求对应码长
    length_k = average_length(length_k, source, k)  # 求平均码长
    h = Hx(H, source)  # 求信源熵
    codeword()  # 求码字
    efficiency(h, length_k)  # 求编码效率
