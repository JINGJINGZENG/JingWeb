# 学号：631810040303
# 姓名：曾晶晶
# 编写时间：2021/11/17
from Shannon import init, average_length, Hx, efficiency

Fs = {}
# 0.25,0.25,0.20,0.15,0.10,0.05
# a1,a2,a3,a4,a5,a6
k = {}  # 码长
length_k = 0  # 平均码长
code = {}  # 符号及其对应的码字集合
H = 0  # 信源熵
# 编码空间
Fs_code = {}


def codeword_Fano(p, fcode):
    # 最后只剩两个没分，或者全部分完了
    if len(p) == 1:
        return 1

    # 最佳分组位置
    flag = 1
    find_position = 0
    sum1 = 0
    # 记录差值
    i = 0
    for item in p:
        sum2 = 0
        i += 1
        sum1 += float(p[item])
        for it in reversed(p):
            if item == it:
                break
            sum2 += float(p[it])
        difference = abs(sum2 - sum1)
        if difference < flag:
            flag = difference
            find_position = i
        else:
            break

    # 分组
    j = 0
    leftgroup = p.copy()
    rightgroup = p.copy()
    for item in p:
        if j < find_position:
            fcode[item] += '0'
            del rightgroup[item]
        else:
            fcode[item] += '1'
            del leftgroup[item]
        j += 1

    # 递归编码
    codeword_Fano(leftgroup, fcode)
    codeword_Fano(rightgroup, fcode)

    # 返回编码空间
    return fcode


def code_length2(k, Fs_code):
    for item in Fs_code:
        k[item] = len(Fs_code[item])
    print('码长：{}'.format(k))
    return k


if __name__ == '__main__':
    # 利用字典的形式存储信源符号及其概率
    # 输入信源概率模型
    print('以下为费诺编码过程')
    Fs = init()
    # 将概率值从大到小排序
    Fs = sorted(Fs.items(), key=lambda kv: kv[1], reverse=True)
    Fs = dict(Fs)
    print("将概率值从大到小排序:{}".format(Fs))
    # 信源编码初始化
    Fs_code = Fs.copy()
    for item in Fs_code:
        Fs_code[item] = ''
    # 求码字
    Fs_code = codeword_Fano(Fs, Fs_code)
    print("信源符号及对应码字为:{}".format(Fs_code))
    # 求对应码长
    k = Fs.copy()
    k = code_length2(k, Fs_code)
    length_k = average_length(length_k, Fs, k)
    H = Hx(H, Fs)  # 求信源熵
    efficiency(H, length_k)  # 求编码效率
