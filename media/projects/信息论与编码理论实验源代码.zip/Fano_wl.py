from Shannon_wl import init, average_length, Hx, efficiency



def codeword_Fano(p, fcode):
    if len(p) == 1:
        return 1
    # 最佳分组位置
    flag = 1
    find_position = 0
    sum1 = 0
    # 记录差值
    i = 0
    for item in p:
        sum2 = 0
        i += 1
        sum1 += float(p[item])
        for it in reversed(p):
            if item == it:
                break
            sum2 += float(p[it])
        difference = abs(sum2 - sum1)
        if difference < flag:
            flag = difference
            find_position = i
        else:
            break
    # 分组
    j = 0
    leftgroup = p.copy()
    rightgroup = p.copy()
    for item in p:
        if j < find_position:
            fcode[item] += '0'
            del rightgroup[item]
        else:
            fcode[item] += '1'
            del leftgroup[item]
        j += 1
    # 递归编码
    codeword_Fano(leftgroup, fcode)
    codeword_Fano(rightgroup, fcode)
    # 返回编码空间
    return fcode

def code_length2(k, Fs_code):
    for item in Fs_code:
        k[item] = len(Fs_code[item])
    print('码长：\n{}'.format(k))
    return k

Fs = {}
k = {}  # 码长
ak = 0  # 平均码长
code = {}  # 符号及其对应的码字集合
H = 0  # 信源熵
Fs_code = {}    # 编码空间
if __name__ == '__main__':
    print('费诺编码')
    Fs = init()
    Fs = sorted(Fs.items(), key=lambda kv: kv[1], reverse=True)
    Fs = dict(Fs)
    print("将概率值从大到小排序:\n{}".format(Fs))
    Fs_code = Fs.copy()
    for item in Fs_code:
        Fs_code[item] = ''
    Fs_code = codeword_Fano(Fs, Fs_code)
    print("信源符号及对应码字为:\n{}".format(Fs_code))
    k = Fs.copy()
    k = code_length2(k, Fs_code)
    ak = average_length(ak, Fs, k)
    H = Hx(H, Fs)  # 求信源熵
    efficiency(H, ak)  # 求编码效率
