# 学号：631810040303
# 姓名：曾晶晶
# 编写时间：2021/11/17
from Fano_wl import code_length2
from Shannon_wl import init, Hx, efficiency

def huffmanCode(root, tree, rootCode='', codeDict={}, depth=1, res=0):
    if len(root['left'][0]) / 2 == 1:
        codeDict[root['left'][0]] = '0' + rootCode
        res += (len(rootCode) + 1) * root['left'][1]  # 计算平均位数
    else:
        codeDict, res = huffmanCode(tree[root['left'][0]], tree, '0' + rootCode, codeDict, depth + 1, res)
    if len(root['right'][0]) / 2 == 1:
        codeDict[root['right'][0]] = '1' + rootCode
        res += (len(rootCode) + 1) * root['right'][1]  # 计算平均位数
    else:
        codeDict, res = huffmanCode(tree[root['right'][0]], tree, '1' + rootCode, codeDict, depth + 1, res)
    return codeDict, res

print('哈夫曼编码')
Hfs = init()
Hs = sorted(Hfs.items(), key=lambda kv: kv[1])  # 将概率值从大到小排序

# 建立哈夫曼树
tree = {}
while len(Hs) > 1:
    # 排序
    Hs.sort(key=lambda kv: kv[1])
    # 选出最小的两个节点，分别作为左子树，右子树
    l = (Hs[0])
    r = (Hs[1])
    if len(Hs) > 2:
        tree[l[0] + r[0]] = {'left': l, 'right': r}
        # 用新节点置换这两个节点
        Hs = Hs[2:]
        Hs.append((l[0] + r[0], l[1] + r[1]))
    else:
        tree['root'] = {'left': l, 'right': r}
        break
# 编码
code, res = huffmanCode(tree['root'], tree)
print('码字：{}'.format(code))
# 对应码长及平均码长
k = Hfs.copy()
k = code_length2(k, code)
length_k = res / sum(Hfs.values())
print('平均码长：{:.3}'.format(res / sum(Hfs.values())))
H = 0
H = Hx(H, Hfs) # 信息熵H
efficiency(H, length_k)  # 编码效率
