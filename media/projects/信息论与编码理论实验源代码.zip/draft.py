# 学号：631810040303
# 姓名：曾晶晶
# 编写时间：2021/11/16
from decimal import *
inp = 'a2'
print(len(inp),len(inp)/2)