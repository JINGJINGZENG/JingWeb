import math

def init():
    ss = input('输入信源符号：')
    sp = eval(input('输入信源符号对应的概率：'))
    ss_list = ss.split(",")
    xy = dict(zip(ss_list, sp))
    print('信源模型为:\n{}'.format(xy))
    return xy

def probability_summation():
    m = 0.0
    ps.append(m)
    for i in list(xy.values()):
        ps.append(round(m + float(i), 4))
        m += float(i)
        if len(ps) == len(xy):
            break
    print("累加概率依次为：\n{}".format(ps))

def code_length(k1):
    for item in xy:
        k1[item] = math.ceil(math.log(float(xy.get(item)), 2) * (-1))
    print('码长：\n{}'.format(k))
    return k1

def average_length(lk, s, kd):
    for item in s:
        lk += float(kd[item]) * float(s[item])
    print("平均码长为：\n{:.3}(bit/sign)".format(lk))
    return lk

def Hx(h, s):
    for item in s:
        h += float(s[item]) * math.log(float(s[item]), 2) * (-1)
    print('信源熵：\n{:.5}(bit/sign)'.format(h))
    return h

def float_to_bin(px, lk):
    b = []
    while True:
        px *= 2
        b.append(1 if px >= 1 else 0)
        px -= int(px)
        if px == 0 and len(b) != lk:
            b.append('0' * (lk - len(b)))
            break
        elif len(b) == lk:
            break
    return b

def codeword():
    code = xy.copy()  # 对应码字
    i = 0
    for item in xy:
        e = ''
        j = 0
        bin = float_to_bin(float(ps[i]), k[item])
        while len(e) != k[item]:
            e += str(bin[j])
            j += 1
        code[item] = e
        i += 1
    print('码字：\n{}'.format(code))

def efficiency(hx, lk):
    print('编码效率：\n{:.2%}'.format(hx / round(lk, 3)))

xy = {}
ps = []  # 概率累加和
k = {}  # 对应码长
ak = 0  # 平均码长
H = 0  # 信源熵

if __name__ == '__main__':
    print('香农编码')
    xy = init()  # 输入信源概率模型
    xy = sorted(xy.items(), key=lambda kv: kv[1], reverse=True)  # 将概率值从大到小排序
    xy = dict(xy)
    print("将信源符号按概率从大到小排序:\n{}".format(xy))
    probability_summation()  # 求概率累加和
    k = xy.copy()
    k = code_length(k)  # 求对应码长
    ak = average_length(ak, xy, k)  # 求平均码长
    h = Hx(H, xy)  # 求信源熵
    codeword()  # 求码字
    efficiency(h, ak)  # 求编码效率